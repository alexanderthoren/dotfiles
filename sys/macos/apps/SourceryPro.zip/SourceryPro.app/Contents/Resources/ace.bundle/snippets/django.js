define("ace/snippets/django",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText = "# Model Fields\n\
\n\
# Code Skeletons\n\
\n\
snippet for\n\
	{% for ${1:name} in ${2:array} %}\n\
		${3:}\n\
	{% endfor %}\n\
\n\
snippet if\n\
	{% if ${1:value} %}\n\
		${2:}\n\
	{% endif %}\n\
\n\
snippet ifelse\n\
	{% if ${1:value} %}\n\
		${2:}\n\
	{% else %}\n\
		${3:}\n\
	{% endif %}\n\
\n\
snippet macro\n\
	{% macro ${1:name} ${2:arg1} %}\n\
		${3:}\n\
	{% endmacro %}\n\
\n\
snippet call\n\
	{% call ${1:function} ${2:arg1} %}\n\
\n\
snippet set\n\
	{% set ${1:name} %} {2:value} {% endset %}\n\
\n\
snippet map\n\
	{% map ${1:variable} into ${2:name} using ${3:itemName} %}\n\
		${4:}	\n\
	{% endmacro %}\n\
";
exports.scope = "django";

});                (function() {
                    window.require(["ace/snippets/django"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            