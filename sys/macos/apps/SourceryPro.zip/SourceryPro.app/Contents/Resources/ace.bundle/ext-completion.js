define("ace/ext/completion",["require","exports","module","require","exports"],function(e,t,n){function i(t,n,i){typeof t=="function"&&(i=t,n=["require","exports","module"],t=r.module.id),typeof t!="string"&&(i=n,n=t,t=r.module.id),i||(i=n,n=[]);var s=typeof i=="function"?i.apply(r.module,n.map(function(t){return r[t]||e(t)})):i;s!=undefined&&(r.module.exports=s)}var r={require:e,exports:t,module:n};t=undefined,n=undefined,i.amd=!0,i(["require","exports"],function(e,t){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.convertToCompletion=void 0;var n=function(e,t){var n=e.Name,r=e.Type,i=t?"variable":e.CustomMeta||"declaration",s={caption:n,meta:i,type:r,parent:t,score:1,description:e.Description,onlyInLocalContext:e.OnlyInLocalContext},o="";return o?(s.snippet=o,s.value=o):s.value=n,s};t.convertToCompletion=n})});
                (function () {
                    window.require(["ace/ext/completion"], function (m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            