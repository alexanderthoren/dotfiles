;
                (function () {
                    window.require(["ace/snippets/twig"], function (m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            