define("ace/snippets/stencil",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="# Model Fields\n\n# Code Skeletons\n\nsnippet for\n	{% for ${1:name} in ${2:array} %}\n		${3:}\n	{% endfor %}\n\nsnippet if\n	{% if ${1:value} %}\n		${2:}\n	{% endif %}\n\nsnippet ifelse\n	{% if ${1:value} %}\n		${2:}\n	{% else %}\n		${3:}\n	{% endif %}\n\nsnippet macro\n	{% macro ${1:name} ${2:arg1} %}\n		${3:}\n	{% endmacro %}\n\nsnippet call\n	{% call ${1:function} ${2:arg1} %}\n\nsnippet set\n	{% set ${1:name} %} {2:value} {% endset %}\n\nsnippet map\n	{% map ${1:variable} into ${2:name} using ${3:itemName} %}\n		${4:}	\n	{% endmacro %}\n\nsnippet newline\n	{% newline %}\n\nsnippet typed\n	{% typed ${1:variable} as ${2:name} %}\n",t.scope="stencil"});
                (function () {
                    window.require(["ace/snippets/stencil"], function (m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            