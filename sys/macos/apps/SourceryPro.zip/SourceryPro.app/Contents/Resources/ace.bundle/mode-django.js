define("ace/mode/django",["require","exports","module","ace/lib/oop","ace/mode/text","ace/token_iterator","ace/mode/stencil_highlight_rules"], function(require, exports, module) {
    "use strict";

    var oop = require("../lib/oop");
    var TextMode = require("./text").Mode;
    var TokenIterator = require("../token_iterator").TokenIterator;
    var StencilHighlightRules = require("./stencil_highlight_rules").StencilHighlightRules;

    var StencilCompletions = function() {};

    (function() {

        function is(token, type) {
            return token.type === type;
        }

        function findTagName(session, pos) {
            var iterator = new TokenIterator(session, pos.row, pos.column);
            var token = iterator.getCurrentToken();
            while (token && !is(token, "tag-name")) {
                token = iterator.stepBackward();
            }
            if (token)
                return token.value;
        }

        function findAttributeName(session, pos) {
            var iterator = new TokenIterator(session, pos.row, pos.column);
            var token = iterator.getCurrentToken();
            while (token && !is(token, "attribute-name")) {
                token = iterator.stepBackward();
            }
            if (token)
                return token.value;
        }

        const _tagElements = [
            "for",
            "map",
            "macro",
            "set",
            "call",
            "if",
            "ifnot"
        ]

        function _getTagCompletions(state, session, pos, prefix) {
            return _tagElements.map(function(element, index) {
                return {
                    value: element,
                    meta: "tag",
                    score: 1000000 - index
                };
            });
        }

        this.getCompletions = function(state, session, pos, prefix) {
            var iterator = new TokenIterator(session, pos.row, pos.column);
            var token = iterator.getCurrentToken();
            if (token && is(token, "text")) {
                token = iterator.stepBackward();
            }

            if (!token) {
                return [];
            }

            if (is(token, "support.function") && token.value === "{%") {
                return _getTagCompletions(state, session, pos, prefix);
            }

            return [];
        };
    }).call(StencilCompletions.prototype);

    var Mode = function() {
        TextMode.call(this);
        this.$keywordList = [];
        this.$completer = new StencilCompletions();
        this.getCompletions = this.$completer.getCompletions;
        this.HighlightRules = StencilHighlightRules;
    };

    oop.inherits(Mode, TextMode);

    (function() {
        this.$id = "ace/mode/django";
        this.snippetFileId = "ace/snippets/django";
    }).call(Mode.prototype);

    exports.Mode = Mode;
});                (function() {
                    window.require(["ace/mode/django"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            